---
name: Monochrome Crema
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4c4546'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dcdddd'
  on-secondary-container: '#5f6161'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1c'
  on-tertiary-container: '#838484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c7c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.1em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.1'
spacing:
  unit: 4px
  gutter: 16px
  margin: 24px
  container-max: 1200px
---

## Brand & Style
The design system is built for "Crema," an espresso tracking application that treats coffee brewing as a precise, architectural craft. The brand personality is professional, refined, and unapologetically minimalist. It targets the "prosumer" espresso enthusiast who values data, repeatability, and aesthetic clarity.

The visual style is **Minimalist & Architectural**, drawing inspiration from high-end editorial design and brutalist structuralism. By removing all rounded corners and color distractions, the UI directs the user's focus entirely toward the ritual of brewing. The emotional response is one of calm authority—transforming the daily espresso pull into a curated, sophisticated experience.

## Colors
The palette is strictly monochrome, utilizing high-contrast black and white to establish hierarchy.

- **Primary (#000000):** Used for primary actions, headings, and critical UI strokes.
- **Surface (#FFFFFF):** The foundational background for all screens, ensuring a "crisp" and airy feel.
- **Accents (#F2F2F2 & #999999):** Subtle cool grays are used exclusively for secondary surfaces, dividers, and disabled states to maintain depth without breaking the monochrome theme.
- **Semantic Colors:** Use black for success/active states and subtle gray for error states to maintain the aesthetic; avoid typical red/green indicators where possible, favoring icons or text labels.

## Typography
The typography system pairs a classic, high-contrast serif with a utilitarian sans-serif.

- **Headlines:** Playfair Display provides a sophisticated, editorial feel. Use large sizes with tight line heights to create a "title-heavy" hierarchy typical of luxury catalogs.
- **Body & Data:** Inter is used for all functional text, brew parameters, and inputs. It provides the technical balance to the serif's elegance.
- **Labels:** Small, uppercase labels with tracking (letter-spacing) should be used for metadata like "GRIND SIZE" or "EXTRACTION TIME."

## Layout & Spacing
This design system utilizes a **Fixed Grid** model on desktop and a **Fluid Column** model on mobile.

- **Rhythm:** An 8px base grid drives all spacing. 
- **Margins:** Generous white space is a core component of the brand. Horizontal margins should never drop below 24px on mobile to maintain the "premium" feel.
- **Structure:** Content is organized in stacked, horizontal bands. Avoid complex nested grids; favor a clean vertical flow that mirrors a printed recipe or technical log.
- **Breakpoints:**
  - Mobile: 4 columns, 16px gutter.
  - Tablet: 8 columns, 24px gutter.
  - Desktop: 12 columns, 32px gutter (max-width 1200px).

## Elevation & Depth
In alignment with the architectural style, the system eschews traditional shadows and blurs.

- **Flat Layering:** Hierarchy is created through tonal stacking (e.g., a white card on a #F2F2F2 background).
- **Hard Borders:** Depth is established using 1px solid black or #E0E0E0 borders. 
- **Zero Transparency:** Do not use glassmorphism. Surfaces are 100% opaque to maintain a solid, grounded feel.
- **Negative Space:** Elevation is often implied through the "void"—using significant whitespace to isolate primary focus areas instead of lifting them off the page.

## Shapes
The shape language is strictly **Sharp and Angular**.

- **Corner Radius:** All elements (buttons, inputs, cards, image containers) must have a 0px border radius. 
- **Icons:** Use thin-stroke, geometric icons (1.5px weight). Avoid rounded icon sets; prefer icons with sharp terminators.
- **Dividers:** Use 1px horizontal and vertical lines to separate data points, echoing the look of a technical blueprint or ledger.

## Components
- **Buttons:** Primary buttons are solid black rectangles with white Inter-Medium text in all-caps. Secondary buttons are 1px black outlines with black text. No rounded corners.
- **Input Fields:** Bottom-border only (minimalist style) or full 1px black boxes. Focus states are indicated by a thickening of the border to 2px.
- **Cards:** White backgrounds with a 1px #000000 or #F2F2F2 border. No shadow.
- **Chips/Tags:** Sharp-edged rectangular boxes with #F2F2F2 backgrounds and small, tracked uppercase text.
- **Brew Log Lists:** Clean, 1px horizontal dividers between entries. Use Playfair Display for the "Espresso Name" and Inter for the "Yield/Time" data.
- **Photography Accents:** All imagery must be high-contrast, minimalist, and framed in sharp-edged containers. Subtle grayscale filters should be applied to maintain color consistency.