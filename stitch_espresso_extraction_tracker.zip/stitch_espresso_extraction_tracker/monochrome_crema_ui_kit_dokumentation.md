# Design System: Monochrome Crema (UI Kit)

Dieses Dokument definiert die atomaren Design-Elemente der "Monochrome Crema" Ästhetik. Der Stil ist geprägt von einer minimalistischen, hochkontrastigen Schwarz-Weiß-Palette mit scharfkantiger Geometrie und eleganter Serif-Typografie.

---

## 1. Farben (Color Palette)

### Hintergrund & Oberflächen (Background & Surface)
*   **Surface (Main):** `#f9f9f9` (Ein sehr helles, fast weißes Grau für den Haupt-Hintergrund)
*   **Surface-Bright:** `#ffffff` (Reines Weiß für Container-Hintergründe)
*   **Surface-Dim:** `#dadada` (Dezentes Grau für Trenner oder Hintergrund-Elemente)
*   **Surface-Container:** `#ffffff` (Karten und Container nutzen meist reines Weiß)

### Brand- & Akzentfarben
*   **Primary:** `#000000` (Tiefschwarz für Buttons, Icons und wichtige Texte)
*   **On-Primary:** `#ffffff` (Weiß für Text auf schwarzen Buttons)

### Textfarben
*   **Headline/Title:** `#000000` (Voller Kontrast)
*   **Body Text:** `#1c1c1c` (Sehr dunkles Grau/Schwarz für gute Lesbarkeit)
*   **Support/Placeholder:** `#757575` (Mittleres Grau für Hilfstexte und Platzhalter)
*   **Disabled Text:** `#bdbdbd` (Hellgrau für deaktivierte Zustände)

### Statusfarben
*   **Success:** `#000000` (Status wird oft durch Symbole oder Checkmarks in Schwarz dargestellt)
*   **Error:** `#000000` (Oft durch Unterstreichungen oder spezifische Icons gelöst; klassisches Rot wird im "Monochrome"-Kontext meist vermieden oder sehr dezent eingesetzt)

---

## 2. Typografie (Typography)

### Schriftarten
*   **Serif (Display):** *Playfair Display* (Für Überschriften, bringt Eleganz und Luxus)
*   **Sans-Serif (UI):** *Inter* oder *Montserrat* (Für funktionale Texte, Daten und Buttons)

### Hierarchien
| Ebene | Font | Size | Weight | Line-Height | Case |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **H1 (Large Title)** | Serif | 32px-40px | Bold | 1.2 | Sentence |
| **H2 (Section Header)** | Serif | 24px | Bold | 1.3 | Sentence |
| **H3 (Subhead)** | Sans | 18px | Semi-Bold | 1.4 | Sentence |
| **Body (Standard)** | Sans | 16px | Regular | 1.5 | - |
| **Label (Caps)** | Sans | 12px | Bold | 1.2 | Uppercase |
| **Caption/Support** | Sans | 12px-14px | Regular | 1.4 | - |
| **Button Text** | Sans | 14px | Bold | 1 | Uppercase |

---

## 3. Buttons

### Styling-Prinzipien
*   **Border-Radius:** `0px` (Absolut scharfkantig)
*   **Padding:** `12px 24px` (Horizontal großzügig)
*   **Schatten:** Keine (Flat Design)

### Typen
*   **Primary:** Hintergrund `#000000`, Text `#ffffff`, Uppercase, scharfe Ecken.
*   **Secondary/Outline:** Hintergrund `transparent`, Rahmen `1px solid #000000`, Text `#000000`.
*   **Ghost/Text-Only:** Hintergrund `transparent`, Text `#000000`, oft mit Icon kombiniert.

---

## 4. Eingabefelder (Inputs)

*   **Styling:** Meist als "Underline"-Input oder mit dezentem `1px` Rahmen unten.
*   **Ecken:** Scharf (`0px`).
*   **Background:** `transparent` oder `#f3f3f4`.
*   **Zustände:** 
    *   *Default:* `#dadada` Rahmen unten.
    *   *Active/Focus:* `#000000` Rahmen unten (Stärke evtl. 2px).
*   **Labeling:** Labels stehen über dem Feld, klein und oft in Uppercase.

---

## 5. Auswahlmöglichkeiten (Controls)

*   **Checkboxen:** Quadratisch, `0px` Radius, schwarzer Rahmen. Im aktiven Zustand schwarz ausgefüllt mit weißem Checkmark.
*   **Slider (Experimental):** Schwarze Linie, schwarzer kreisförmiger "Thumb" (hier ist ausnahmsweise Rundung für die Ergonomie erlaubt) oder quadratischer Thumb.
*   **Segments/Tabs:** Scharfkantige Boxen, aktiver Zustand ist schwarz mit weißem Text.

---

## 6. Navigation

*   **Top Bar:** Zentriertes Logo (Serif), flankiert von minimalistischen Icons oder Text-Buttons ("SAVE", "CLOSE").
*   **Bottom Nav:** Schwarze Icons auf weißem Grund.
*   **Aktiver Zustand:** Der aktive Tab wird oft durch eine vollflächig schwarze Box (Invertierung) oder eine fette Unterstreichung hervorgehoben.

---

## 7. Icons

*   **Stil:** Linear / Outline.
*   **Strichstärke:** `1.5px` bis `2px`.
*   **Form:** Eher geometrisch und klar definiert, keine verspielten Rundungen.
*   **Größe:** Basisraster `24x24px`.

---

## 8. Container & Layout

*   **Karten (Cards):** Weißer Hintergrund, scharfe Ecken (`0px`), oft durch eine feine `1px` Outline in `#dadada` oder durch Schlagschatten-Abgrenzung (sehr dezent) definiert.
*   **Divider:** Horizontale Linien, `1px` Stärke, Farbe `#000000` oder `#dadada` je nach Hierarchie.
*   **Spacing:** Strenges 8px-Raster-System für konsistente Abstände.
